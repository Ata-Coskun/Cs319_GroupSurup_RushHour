package rushHour;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class GameEngine extends JPanel implements MouseListener, MouseMotionListener{
	static int xDragged=0,yDragged=0;
	static int xClicked=0, yClicked=0;
	Board board;
	int numberOfMoves;
	int levelNo;
	MouseListener ml;
	MouseMotionListener mml;
	
	public GameEngine(Board board, int level) {
		numberOfMoves = 0;
		this.board = board;
		System.out.println("The initial board");
	}
	
	void paint(){
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				System.out.print(board.coordinates[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("\n");
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.yellow);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		Image boardImage= new ImageIcon("board.png").getImage();
		g.drawImage(boardImage, 0, 0, 450,450,this);
		if( numberOfMoves == 0) {
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 6; j++) {
					if( board.coordinates[i][j] == 2) {
						Image rock = new ImageIcon("rock.png").getImage();
						g.drawImage(rock, j*75, i*75, 75, 75,this);
					}
					else if( board.coordinates[i][j] == 1 ) {
						if( board.searchCoordinates(i,j) != null && board.searchCoordinates(i,j).direction == false && board.searchCoordinates(i,j).carType != 0){//if car is horixantal
							Image car = new ImageIcon("7.png").getImage();
							g.drawImage(car, j*75, i*75, 150, 75, this);
							j += 2;
							g.setColor(Color.red);
							g.fillRect(425, i*75, 25, 75);
						}
							if( board.searchCoordinates(i,j) != null && board.searchCoordinates(i,j).direction == false && board.searchCoordinates(i,j).size == 2){//if car is horixantal
								Image car = new ImageIcon("6.png").getImage();
								g.drawImage(car, j*75, i*75, 150, 100, this);
								j += 2;
							}
							if( board.searchCoordinates(i,j) != null && board.searchCoordinates(i,j).direction == false && board.searchCoordinates(i,j).size == 3){//if car is horixantal
								Image car = new ImageIcon("4.png").getImage();
								g.drawImage(car, j*75,i*75, 200, 75, this);
								j += 3;
							}
					}
				}
			}
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 6; j++) {
					if( board.coordinates[j][i] == 1 ) {
						if( board.searchCoordinates(j,i) != null && board.searchCoordinates(j,i).direction == true && board.searchCoordinates(j,i).size == 2){//if car is horixantal
							Image car = new ImageIcon("10.png").getImage();
							g.drawImage(car, i*75, j*75, 75, 150, this);
							j += 2;
						}
						if( board.searchCoordinates(j,i) != null && board.searchCoordinates(j,i).direction == true && board.searchCoordinates(j,i).size == 3){//if car is horixantal
							Image car = new ImageIcon("10.png").getImage();
							g.drawImage(car, i*75, j*75, 75, 225, this);
							j += 3;
						}
					}
				}
			}
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {}
	@Override
	public void mousePressed(MouseEvent e) {
		xClicked = e.getX()/75;
	    yClicked = e.getY()/75;
	    repaint();
	}
	@Override
	public void mouseClicked(MouseEvent e){
		
	}
	@Override
	public void mouseReleased(MouseEvent e){
		
	}
	
	@Override
	public void mouseDragged(MouseEvent e){
		xDragged = e.getX()/75;
		yDragged = e.getY()/75;
		board.moveCar( yClicked,xClicked, yDragged,xDragged);
		repaint();
	}
	@Override
	public void mouseEntered(MouseEvent e){}
	@Override
	public void mouseExited(MouseEvent e){}

}


