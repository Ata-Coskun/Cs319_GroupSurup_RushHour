"# Cs319_GroupSurup_RushHour" 
"# Cs319_GroupSurup_RushHour" 
"# Cs319_GroupSurup_RushHour" 
"# Cs319_GroupSurup_RushHour" 
"# Cs319_GroupSurup_RushHour" 
"# Cs319_GroupSurup_RushHour"

Section-1

Name of The Group: GURUP ŞURUP 

Members of Group Surup:
1. Zeynep Nur Öztürk- 21501472
2. Muhammet Said Demir - 21602021
3. Ata Coşkun- 21503061
4. Tarık Emin Kaplan- 21601737
5. Asuman Aydın- 21502604

Rush Hour:

-- The goal of the game is to move the red car to the exit by going up and down or right and left.

-- The features we planned to add to this game are other types of obstacles (spike strokes etc.). There is of course time and keeping score . In addition to the points, there will be also bonus points to give to more successful performances of the users. To detect that we can use time and the number of moves. 

-- Other than time and bonus points,To expand the game, the idea for barriers are also bridges to pass over the cars depending on the level challenge and 3D mode. In some levels, when the red car encounters an unmovable barrier, the red car needs to move vertically one step further. For that, there will be a power-up given depending on the performance of the user as a bonus.
