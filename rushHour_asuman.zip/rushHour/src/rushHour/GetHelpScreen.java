package rushHour;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GetHelpScreen extends JPanel implements MouseListener, MouseMotionListener, ActionListener {
	JButton helpReturn = new JButton("RETURN");
	static int iDragged = 0, jDragged = 0;
	static int iClicked = 0, jClicked = 0;
	JFrame f2 = new JFrame("How to Play");
	boolean x;

	public GetHelpScreen() throws IOException {
		// help frame
		
		helpReturn.setBackground(Color.yellow);
		helpReturn.setForeground(Color.red);
		helpReturn.addActionListener(this);
		
		JPanel panelX = new JPanel();
		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f2.setBounds(800, 700, 700, 700);
		f2.setVisible(true);
		f2.setSize(700, 700);
		BufferedImage logoGame = ImageIO.read(new File("help.png"));
		JLabel logoLabel = new JLabel(new ImageIcon(logoGame));
		logoLabel.setBounds(900, 800, 900, 800);
		helpReturn.setBounds(0, 0, 50, 50);
		panelX.add(helpReturn);
		panelX.add(logoLabel);
		f2.add(panelX);
		f2.setLocationRelativeTo(null);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.orange);
		repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == helpReturn) {
			f2.setVisible(false);
			try {
				MainScreen returning = new MainScreen(1,x);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {

		x = true;

		iClicked = e.getY() / 30;
		jClicked = e.getX() / 30;
		repaint();
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		iDragged = e.getY() / 30;
		jDragged = e.getX() / 30;
		repaint();
	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}
}