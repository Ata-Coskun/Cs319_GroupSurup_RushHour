package rushHour;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MultiLevelSelection extends JPanel implements ActionListener {

	MultiGameEngine engine;
	JButton btn, gameModeReturn;
	JButton btn2;
	JFrame f, f1;
	JPanel panel = new JPanel();
	static Board board;

	public MultiLevelSelection(/*boolean gameMode*/) throws IOException {
		
		panel.setLayout(null);
		btn = new JButton();
		gameModeReturn = new JButton("RETURN");
		gameModeReturn.addActionListener(this);
		gameModeReturn.setBounds(0,0,200,30);
		gameModeReturn.setBackground(Color.yellow);
		gameModeReturn.setForeground(Color.red);
		btn.addActionListener(this);
		btn.setBounds(50, 50, 300, 300);
		btn2 = new JButton();
		btn2.addActionListener(this);
		btn2.setBounds(50, 350, 300, 300);
		// level1
		Image img2 = new ImageIcon("level1.png").getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
		btn.setIcon(new ImageIcon(img2));
		// level2
		Image img3 = new ImageIcon("level2.png").getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
		btn2.setIcon(new ImageIcon(img3));
		// texts

		JLabel label1 = new JLabel("Level 1 Score: 100 ");
		label1.setBounds(400, 50, 300, 300);
		label1.setFont(new Font("Serif", Font.PLAIN, 25));
		JLabel label2 = new JLabel("Level 2 Score:  ");
		label2.setBounds(400, 350, 300, 300);
		label2.setFont(new Font("Serif", Font.PLAIN, 25));
		// score star image example
		BufferedImage toScore = null;
		try {
			toScore = ImageIO.read(new File("star.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JLabel labelMe = new JLabel(new ImageIcon(toScore));
		labelMe.setBounds(500, 180, 100, 100);

		// frame
		f = new JFrame("Select Levels");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		BufferedImage img = ImageIO.read(new File("background.png"));
		f.setContentPane(new JLabel(new ImageIcon(img)));
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		f.add(label1, gbc);
		f.add(label2, gbc);
		f.add(labelMe, gbc);
		f.add(btn, gbc);
		f.add(btn2, gbc);
		f.add(gameModeReturn,gbc);
		// adding to the frame
		f.setSize(700, 700);
		f.setVisible(true);
		f.setLocationRelativeTo(null);

		// LevelSelection selection = new LevelSelection(1);
	}

	public MultiLevelSelection(int level) {
		startMultiLevel(level);
	}
	@Override
	public void actionPerformed(ActionEvent e) {

		// S.close();

		if (e.getSource() == btn) {
			f.setVisible(false);
			startMultiLevel(1);
		} else if (e.getSource() == btn2) {
			f.setVisible(false);
			startMultiLevel(2);
		}
		if(e.getSource() == gameModeReturn)
		{
			f.setVisible(false);
			try {
				MultiLevelSelection returning = new MultiLevelSelection();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.pink);

	}
	public void startMultiLevel(int level) {
		Stack Q = new Stack<Integer>();
		if (level == 1) {
			board = new Board(true);
			board.setInitialBoard();
			board.setCar(9, 9, 0, 1, 1);
			board.setCar(9, 11, 3, 3, 0);
			board.setCar(8, 9, 4, 4, 0);
			board.setCar(12, 13, 4, 4, 0);
			board.setCar(10, 11, 5, 5, 0);
			board.setCar(10, 11, 8, 8, 0);
			board.setCar(8, 9, 9, 9, 0);
			board.setCar(12, 13, 9, 9, 0);
			board.setCar(10, 12, 10, 10, 0);
			board.setCar(12, 12, 12, 13, 2);
	
			engine = new MultiGameEngine(board);
			MultiGameScreen multi = new MultiGameScreen(engine);
			f = new JFrame("Multi");
			f.setBackground(Color.MAGENTA);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setBounds(900, 900, 900, 900);
			//f3.add(game);
			f.setResizable(false);
			f.add(multi );//multigame engine
			f.setLocationRelativeTo(null);
			f.setSize(1000,700);
			f.setVisible(true);
			
		} else if (level == 2) 
		{
			board = new Board(true);
			board.setInitialBoard();
			board.setCar(9, 9, 0, 1, 1);
			board.setCar(9, 11, 3, 3, 0);
			board.setCar(8, 9, 4, 4, 0);
			board.setCar(12, 13, 4, 4, 0);
			board.setCar(10, 11, 5, 5, 0);
			board.setCar(10, 11, 8, 8, 0);
			board.setCar(8, 9, 9, 9, 0);
			board.setCar(12, 13, 9, 9, 0);
			board.setCar(10, 12, 10, 10, 0);
			board.setCar(12, 12, 12, 13, 2);
	
			engine = new MultiGameEngine(board);
			MultiGameScreen multi = new MultiGameScreen(engine);
			f = new JFrame("Multi");
			f.setBackground(Color.MAGENTA);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setBounds(900, 900, 900, 900);
			//f3.add(game);
			f.setResizable(false);
			f.add(multi );//multigame engine
			f.setLocationRelativeTo(null);
			f.setSize(1000,700);
			f.setVisible(true);
		}
	}
}
