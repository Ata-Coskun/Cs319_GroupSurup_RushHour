
public class Obstacle {

	int i, j;
	public Obstacle(int i, int j) {
		this.i = i;
		this.j = j;
	}

}
