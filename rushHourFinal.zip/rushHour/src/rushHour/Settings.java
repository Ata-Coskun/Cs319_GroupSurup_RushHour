package rushHour;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * This is the screen that comes when player chooses get help. Player can choose the initial theme and mute setting from here
 */
public class Settings extends JPanel implements ActionListener {

	JButton okButton;
	JButton muteButton;
	JButton theme1, theme2, theme3;
	JFrame f;
	int theme;
	int mute;

	public Settings() throws IOException {
		// initiliazing the data
		theme = 1;
		mute = 0;

		// Frame of this scene
		f = new JFrame("Settings");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("background.png")))));
		f.setSize(700, 700);
		f.setVisible(true);
		f.setLocationRelativeTo(null);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridwidth = GridBagConstraints.REMAINDER;

		// Initiazing buttons
		theme1 = new JButton();
		theme1.setVisible(true);
		theme1.setBounds(200, 100, 300, 100);
		theme1.setForeground(Color.red);
		theme1.setBackground(Color.ORANGE);
		theme1.addActionListener(this);
		theme1.setText("Theme 1");
		theme1.setFont(new Font("Serif", Font.ITALIC, 25));
		f.add(theme1, gbc);

		theme2 = new JButton();
		theme2.setVisible(true);
		theme2.setBounds(200, 200, 300, 100);
		theme2.setForeground(Color.red);
		theme2.setBackground(Color.ORANGE);
		theme2.addActionListener(this);
		theme2.setText("Theme 2");
		theme2.setFont(new Font("Serif", Font.ITALIC, 25));
		f.add(theme2, gbc);

		theme3 = new JButton();
		theme3.setVisible(true);
		theme3.setBounds(200, 300, 300, 100);
		theme3.setForeground(Color.red);
		theme3.setBackground(Color.ORANGE);
		theme3.addActionListener(this);
		theme3.setText("Theme 3");
		theme3.setFont(new Font("Serif", Font.ITALIC, 25));
		f.add(theme3, gbc);

		muteButton = new JButton();
		muteButton.setVisible(true);
		muteButton.setBounds(200, 400, 300, 100);
		muteButton.setForeground(Color.red);
		muteButton.setBackground(Color.ORANGE);
		muteButton.addActionListener(this);
		muteButton.setText("Mute");
		muteButton.setFont(new Font("Serif", Font.ITALIC, 25));
		f.add(muteButton, gbc);

		okButton = new JButton();
		okButton.setVisible(true);
		okButton.setBounds(200, 500, 300, 100);
		okButton.setForeground(Color.red);
		okButton.setBackground(Color.ORANGE);
		okButton.addActionListener(this);
		okButton.setText("OK");
		okButton.setFont(new Font("Serif", Font.ITALIC, 25));
		f.add(okButton, gbc);
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		// return button
		if (evt.getSource() == okButton)
			try {
				f.setVisible(false);
				PrintWriter settingsWriter = new PrintWriter(new File("settings.txt"));
				settingsWriter.println(theme + "," + mute + ",");
				settingsWriter.close();
				new MainScreen();
			} catch (IOException e) {
				e.printStackTrace();
			}
		else if (evt.getSource() == theme1)
			theme = 1;
		else if (evt.getSource() == theme2)
			theme = 2;
		else if (evt.getSource() == theme3)
			theme = 3;
		else if (evt.getSource() == muteButton)
			mute = (mute + 1) % 2;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.pink);
	}

}
