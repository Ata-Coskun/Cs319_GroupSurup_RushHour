package rushHour;

import java.util.Stack;

public class MultiGameEngine extends GameEngine {
	
	Board board;
	Stack<Board> stack;
	int level;
	MultiGameScreen gameScreen;
	
	public MultiGameEngine() {}
	public MultiGameEngine(Board board) {
		this.board = board;
		MultiGameScreen gameScreen = new MultiGameScreen(this);
	}

	@Override
	boolean update(int iClicked, int jClicked, int iDragged, int jDragged) {
		boolean result = this.board.moveBoard(iClicked,jClicked,iDragged);
		return false;
	}

}
