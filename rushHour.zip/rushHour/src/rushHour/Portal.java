package rushHour;

public class Portal {
	
	int i1, i2, j1, j2;
	
	public Portal(int i1, int i2, int j1, int j2) {
		this.i1 = i1;
		this.i2 = i2;
		this.j1 = j1;
		this.j2 = j2;
	}

}
