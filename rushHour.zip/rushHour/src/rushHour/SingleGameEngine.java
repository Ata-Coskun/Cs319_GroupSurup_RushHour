package rushHour;
import java.io.IOException;
import java.util.*;
public class SingleGameEngine extends GameEngine {
	
	Board board;
	Stack<Integer> stack;
	int level;
	SingleGameScreen gameScreen;

	
	public SingleGameEngine(Board board,int level) throws IOException {
		this.board = board;
		this.level = level;
		stack = new Stack<Integer>();
		gameScreen = new SingleGameScreen(this,1);
	}
	
	//@Override 
	public boolean update(int iPressed,int jPressed, int iReleased, int jReleased) {
		boolean result = this.board.moveCar(iPressed,jPressed,iReleased,iReleased, true);
		stack.push(jPressed);
		stack.push(iPressed);
		stack.push(jReleased);
		stack.push(iReleased);
		return result;
	}
	public int calculateScore(int time, int numOfMoves){
		return  1 / (time * numOfMoves) * 100;
	}
	
	

}
