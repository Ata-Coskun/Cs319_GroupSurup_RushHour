/*
*	Author : Ata Co�kun, Muhammet Said Demir
*/

package rushHour;

import java.io.IOException;

/*
 * Main class that starts the game. Run this
 */
public class RushHour {

	public static void main(String[] args) throws IOException {
		new MainScreen();
	}
}