package rushHour;

public class MultiGameScreen {
	
	MultiGameEngine engine;
	public MultiGameScreen(MultiGameEngine engine) {
		this.engine = engine;
	}
}
